#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
// ---------------QUEUE------------------

//QUEUE Veri Tipi Oluşturma

struct node {
    int data;
    struct node *next;
}*front, *rear;

void enqueue(int newData){ //Sıraya yeni eleman ekleme
    struct node *temp = malloc(sizeof(struct node));
    temp -> data = newData;
    temp -> next = NULL;

    if (front == NULL && rear == NULL) //Hiç eleman yoksa
        front = rear = temp; //Başı da sonu da temp olsun
   
    else{ //Eleman varsa (rear son elemandır)
        rear -> next = temp; //son elemanın arkasına tempi ekle
        rear = temp; //yeni rear'ı temp yap
    }
}

void dequeue(){ //Önden işi biteni atma
    if (front == NULL && rear == NULL){ //Boşsa
        printf("Kuyruk boş");
    }

    else{ //Doluysa
        struct node *temp = front; //En öndeki elemanı al 
        front = front -> next; //En önü bi arkaya aktar
        free(temp); //Geçici elemanı sil 
    }
}

void printQueue(){
    bool isEmpty = (front == NULL && rear == NULL);
    if (isEmpty){
        printf("Kuyruk Boş!");
    }

    else{
        struct node *temp = front;
        while (temp != NULL){
            printf("%d", temp -> data);
            temp = temp -> next;
        }
    } 
}


// ---------------STACK------------------

struct node1{
    int data;
    struct node1 *next;
}*top;

//top = NULL;


void push(int value){
    struct node1 *temp; //Datanın atanacağı node u oluştur
    temp = malloc(sizeof(struct node1));
    temp -> data = value; // Datayı ata
    temp -> next = top;
    top = temp; 
}

void pop(){
    if (top != NULL){
        struct node1 *temp;
        temp = top;
        top = top-> next;
        free(temp);
    }
    else printf("Yığın boş!");
}

void display(){
    struct node1 *tmp = top;
    while(tmp != NULL){
        printf("%d\n", tmp -> data);
        tmp = tmp -> next;
    }
}

int main(){
    
    //STACK SAMPLES
    push(0);
    push(1);
    push(2);
    push(3);
    push(4);

    printf("Yığın:\n");
    display();
    printf("\n\n");
    pop();
    pop();
    pop();
    printf("3 Eleman silindi.\n\n");
    display();

    push(3);
    printf("\n\n");
    printf("1 Eleman eklendi.\n\n");
    display();

    //QUEUE SAMPLES
    /*
    front = NULL;
    rear = NULL;
    enqueue(0);
    enqueue(1);
    enqueue(2);
    enqueue(3);

    printQueue();
    printf("\n4 Eleman Eklendi.\n");

    dequeue();
    dequeue();

    printf("\n");
    printQueue();
    printf("\n2 Eleman Silindi.");

    enqueue(4);
    enqueue(5);

    printf("\n\n");
    printQueue();
    printf("\n2 Eleman Eklendi.\n");

    */


    


    



}

