#include <stdio.h>
#include <stdlib.h>

int binarySearch(int arr[], int left, int right, int x){
    if (right >= left){
        int mid = left + (right-left) / 2;
        if (arr[mid] == x) // Eğer ortadaysa direk döndür
            return mid;
        
        if (arr[mid] > x) // Midden küçükse solda demektir
            return binarySearch(arr, left, mid-1, x);

        else // Midden küçükse solda demektir
            return binarySearch(arr, mid+1, right, x);    
    }
    return -1;
}

int araIndex(int arr[], int x){
    for (int i = 0; i < 5; i++)
    {
        if (arr[i] == x) return i;
    }
    return -1;
}

int main(){
    int arr[] = {1,0,3,2,4,5};
    int targetIdx = binarySearch(arr,1,5,1);
//    printf("%d", targetIdx);
    printf("%d", araIndex(arr,3));
}